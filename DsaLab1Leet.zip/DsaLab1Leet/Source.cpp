#include <iostream>
#include<vector>
using namespace std;
//	question no 1

class Solution {
public:
    vector <int> arrResult;
    vector<int> smallerNumbersThanCurrent(vector<int>& nums) {
        arrResult.resize(nums.size());
        for (int i = 0;i < nums.size();i++)
        {
            int count = 0;
            for (int j = 0;j < nums.size();j++)
            {
                if (nums[i] > nums[j])
                {
                    count++;
                }
            }
            arrResult[i] = count;
        }

        return arrResult;
    }
};

//question no 2

class Solution {
public:
    int removeElement(vector<int>& nums, int val) {
        for (int i = 0;i < nums.size();i++)
        {

            if (nums[i] == val)
            {

                for (int k = i;k < nums.size() - 1;k++)
                {
                    nums[k] = nums[k + 1];

                }
                nums.resize(nums.size() - 1);
                i--;
            }
        }
        return nums.size();
    }
};

//question no 3

class Solution {
public:
    bool searchMatrix(vector<vector<int>>& matrix, int target) {
        int flag = 0;
        for (int i = 0;i < matrix.size();i++)
        {
            for (int j = 0;j < matrix[i].size();j++)
            {
                if (matrix[i][j] == target)
                {
                    flag++;
                }
            }

        }
        if (flag >= 1)
        {
            return  true;
        }
        return false;
    }
};

//question no 4

class Solution {
public:
    int removeDuplicates(vector<int>& nums) {
        for (int i = 0;i < nums.size() - 1;i++)
        {
            if (nums[i] == nums[i + 1] && i < nums.size() - 1)
            {
                for (int j = i;j < nums.size() - 1;j++)
                {
                    nums[j] = nums[j + 1];
                }
                nums.resize(nums.size() - 1);
                i--;
            }
        }
        return nums.size();
    }
};

//question no 5

class Solution {
public:
    int maxSubArray(vector<int>& nums) {
        int maxSum = INT_MIN;
        int currentSum = 0;
        for (int i = 0;i < nums.size();i++)
        {
            if (currentSum < 0)
            {
                currentSum = 0;
            }
            currentSum = currentSum + nums[i];
            if (currentSum > maxSum)
            {
                maxSum = currentSum;
            }

        }
        return maxSum;
    }
};

//question no 6

// The API isBadVersion is defined for you.
// bool isBadVersion(int version);
class Solution {
public:
    int firstBadVersion(int n) {
        int low, high, mid;
        low = 0;
        high = n - 1;
        while (low <= high)
        {
            mid = low + (high - low) / 2; 
            if (isBadVersion(mid)) {
                high = mid - 1;
            }
            else
            {
                low = mid + 1;
            }
        }
        return low;
    }
};

//question no 7 

class Solution {
public:
    int firstMissingPositive(vector<int>& nums) {

        int n = nums.size();
        int i = 0;
        while (i < n)
        {
            if (nums[i] > 0 && nums[i] <= n && nums[i] != nums[nums[i] - 1])
            {
                swap(nums[i], nums[nums[i] - 1]);
            }
            else
            {
                i++;
            }
        }
        for (int i = 0;i < n;i++)
        {
            if (nums[i] != i + 1) 
            {
                return i + 1;

            }
        }
        return n + 1;
    }
};